# spring-data-jpa
How to use spring data jpa with rest api
